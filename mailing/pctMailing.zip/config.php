<?php 
$servername='localhost';
$username='edchurchill_usrst';
$password='N@pol3ao';
$dbname='edchurchill_mainsite';